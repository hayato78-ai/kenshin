# CDmedical 健診システム データ構造設計書
## シート・カラム詳細定義（iD-Heart II準拠）

> **バージョン**: 2.0
> **作成日**: 2025-12-20

---

## 1. シート一覧

### マスタ系

| シート名 | 説明 | レコード数目安 |
|----------|------|---------------|
| M_検査項目 | 検査項目定義・判定基準 | 200-500 |
| M_検査所見 | 所見テンプレート | 300-1000 |
| M_コース | 健診コース | 10-50 |
| M_コース項目 | コース-検査項目関連 | 500-2000 |
| M_判定項目 | 部位別判定項目 | 20-50 |
| M_団体 | 企業・団体 | 50-500 |
| M_保険者 | 保険者 | 10-100 |

### トランザクション系

| シート名 | 説明 | レコード数目安 |
|----------|------|---------------|
| T_受診者 | 受診者基本情報 | 1000-50000 |
| T_受診記録 | 受診ごとの情報 | 5000-100000 |
| T_検査結果 | 検査結果（縦持ち） | 100000-1000000 |
| T_所見 | 所見データ | 10000-100000 |
| T_判定 | 判定結果 | 50000-500000 |
| T_進捗 | 進捗管理 | 5000-100000 |

---

## 2. M_検査項目 詳細

### カラム定義（主要カラム）

```
A: item_code        - 項目コード (PK) 例: 011001
B: jlac10_code      - JLAC10コード
C: item_name        - 項目名 例: 身長
D: item_name_kana   - カナ
E: category         - 区分 (身体情報/検体検査/画像診断)
F: sub_category     - 小分類 (身体計測/脂質/血液一般...)
G: data_type        - データ型 (numeric/text/select)
H: decimal_places   - 小数桁数
I: unit             - 単位 (cm, kg, mg/dl...)
J-K: valid_min/max  - 有効範囲
L-M: std_male/female - 帳票基準値表記
N-X: criteria_*_m   - 男性判定基準 (F低〜F高)
Y-AI: criteria_*_f  - 女性判定基準 (F低〜F高)
AJ: default_value   - 初期値
AK: finding_ref     - 所見参照初期値
AL-AO: price_*      - オプション単価
AP-AQ: lab_code     - 検査会社コード
AR: display_order   - 表示順
AS: notes           - 備考
AT: is_active       - 有効フラグ
```

### サンプルデータ

| item_code | item_name | category | unit | std_male |
|-----------|-----------|----------|------|----------|
| 011001 | 身長 | 身体情報 | cm | |
| 011002 | 体重 | 身体情報 | kg | |
| 011025 | BMI | 身体情報 | | 25未満 |
| 011014 | 腹囲 | 身体情報 | cm | 85未満 |
| 011005 | 血圧(最高) | 身体情報 | mmHg | 130未満 |
| 021018 | 総コレステロール | 検体検査 | mg/dl | 150〜219 |
| 021022 | LDL-C | 検体検査 | mg/dl | 120未満 |
| 021020 | HDL-C | 検体検査 | mg/dl | 40以上 |
| 021037 | 空腹時血糖 | 検体検査 | mg/dl | 100未満 |
| 012003 | 心電図 | 画像診断 | | |
| 012012 | 胸部X線 | 画像診断 | | |
| 050000 | eGFR | 検体検査 | | 60以上 |

---

## 3. M_検査所見 詳細

### カラム定義

```
A: finding_code      - 所見コード (PK)
B: finding_name      - 所見名
C: default_judgment  - デフォルト判定
D: exam_item_refs    - 紐づく検査項目
E: is_history        - 既往歴フラグ
F: notes             - 備考
G: display_order     - 表示順
H: is_active         - 有効フラグ
```

### サンプルデータ（iD-Heart参照）

| code | name | judgment | notes |
|------|------|----------|-------|
| 0001 | 異常なし | A | |
| 0002 | 異常あり | C | |
| 0003 | 未提出 | | |
| 0005 | 陳旧性炎症性変化 | B | |
| 0006 | 高血圧 | | 既往歴 |
| 0007 | 心臓病 | | 既往歴 |
| 0116 | ST上昇 | C | |
| 0117 | ST下降 | C | |
| 0118 | 低電位 | B | |
| 0121 | 右室肥大 | C | |
| 0122 | 左室肥大 | C | |

---

## 4. T_検査結果 詳細

### カラム定義

```
A: result_id         - 結果ID (PK)
B: visit_id          - 受診ID (FK)
C: item_code         - 検査項目コード (FK)
D: result_value      - 結果値
E: result_text       - 結果文字（定性）
F: judgment          - 判定
G: judgment_auto     - 自動判定
H: finding_codes     - 所見コード
I: finding_text      - 所見自由記述
J: prev_value        - 前回値
K: prev_prev_value   - 前々回値
L: is_abnormal       - 異常フラグ
M: notes             - 備考
N: created_at        - 作成日時
O: updated_at        - 更新日時
```

### データ例

| visit_id | item_code | result_value | judgment |
|----------|-----------|--------------|----------|
| 20251217-001 | 011001 | 167.7 | * |
| 20251217-001 | 011002 | 66.1 | * |
| 20251217-001 | 011025 | 23.5 | A |
| 20251217-001 | 011005 | 114 | A |
| 20251217-001 | 021022 | 142 | C |

---

## 5. T_進捗 詳細

### カラム定義

```
A: progress_id       - 進捗ID (PK)
B: visit_id          - 受診ID (FK)
C: pre_form          - 事前帳票 (完了/途中/未)
D: reception         - 受付
E: day_form          - 当日帳票
F: questionnaire     - 問診結果
G: physical          - 身体情報
H: lab_test          - 検体検査
I: imaging           - 画像診断
J: specific_health   - 特定健診
K: judgment          - 判定項目
L: findings          - 所見文章
M: report            - 報告書
N: billing_org       - 請求先請求
O: billing_person    - 個人請求
P: payment           - 個人入金
Q: updated_at        - 更新日時
```

### ステータス値

| 値 | 表示 | 説明 |
|----|------|------|
| 完了 | 💚 | 処理完了 |
| 途中 | 💛 | 処理中 |
| 未 | ❤️ | 未処理 |
| 対象外 | ⬜ | 対象外 |

---

## 6. 既存GASコードとの対応

### portalApi.js 対応

```javascript
// 既存 PATIENT_COL → 新構造
const PATIENT_COL = {
  PATIENT_ID: 0,   // A列: P-00001形式
  NAME: 1,         // B列: 氏名
  KANA: 2,         // C列: カナ
  BIRTHDATE: 3,    // D列: 生年月日
  GENDER: 4,       // E列: 性別
  // ...
};

// 既存 VISIT_COL → 新構造
const VISIT_COL = {
  VISIT_ID: 0,     // A列: 20251217-001形式
  PATIENT_ID: 1,   // B列: 受診者ID (FK)
  VISIT_DATE: 2,   // C列: 受診日
  // ...
};
```

### Config.js シート名対応

```javascript
const DB_CONFIG = {
  SHEETS: {
    // マスタ
    EXAM_ITEM: 'M_検査項目',
    FINDING: 'M_検査所見',
    COURSE: 'M_コース',
    ORG: 'M_団体',
    
    // トランザクション
    PATIENT: 'T_受診者',
    VISIT: 'T_受診記録',
    RESULT: 'T_検査結果',
    PROGRESS: 'T_進捗'
  }
};
```

---

## 7. 判定ロジック

### 数値判定

```javascript
function autoJudge(value, gender, criteria) {
  const c = gender === '男性' ? criteria.male : criteria.female;
  
  if (value >= c.f_low && value < c.e_low) return 'F';
  if (value >= c.e_low && value < c.d_low) return 'E';
  if (value >= c.d_low && value < c.c_low) return 'D';
  if (value >= c.c_low && value < c.b_low) return 'C';
  if (value >= c.b_low && value <= c.a_high) return 'B';
  if (value >= c.a_low && value <= c.a_high) return 'A';
  // 高値側も同様
  return '*'; // 判定不可
}
```

### 部位別判定

```javascript
function getAreaJudgment(results, judmentItem) {
  // 関連する検査項目の判定を集計
  const judgments = judmentItem.related_items
    .map(code => results[code]?.judgment)
    .filter(j => j && j !== '*');
  
  // 最も悪い判定を採用
  const priority = ['F', 'E', 'D', 'C', 'B', 'A'];
  return judgments.sort((a, b) => 
    priority.indexOf(a) - priority.indexOf(b)
  )[0] || '*';
}
```

---

## 変更履歴

| 日付 | Ver | 内容 |
|------|-----|------|
| 2025-12-20 | 2.0 | 初版（iD-Heart分析に基づく）|
